package com.example.casostudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasostudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasostudioApplication.class, args);
	}

}
