package com.example.casostudio;

import com.example.casostudio.VoloOperativo;
import com.example.casostudio.VoloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AirportController {

    @Autowired
    private VoloRepository voloRepository;

    // API a) GET /flights/{flightId}
    @GetMapping("/flights/{flightId}")
    public ResponseEntity<VoloOperativo> getFlightById(@PathVariable String flightId) {
        return voloRepository.findById(flightId)
                .map(volo -> ResponseEntity.ok().body(volo))
                .orElse(ResponseEntity.notFound().build());
    }

    // API b) GET /operational_flights
    @GetMapping("/operational_flights")
    public List<VoloOperativo> getAllOperationalFlights() {
        return voloRepository.findAll();
    }
}
