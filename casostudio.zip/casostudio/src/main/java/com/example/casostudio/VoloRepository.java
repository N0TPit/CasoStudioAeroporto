package com.example.casostudio;

import com.example.casostudio.VoloOperativo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VoloRepository extends MongoRepository<VoloOperativo, String> {
}
