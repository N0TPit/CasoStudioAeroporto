package com.example.casostudio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasostudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
